﻿namespace BIGBANG_ASSESMENT3.Models.DTOs
{
    public class TravelagentDTO
    {
        public int id { get; set; }


    }
}
